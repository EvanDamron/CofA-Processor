import SwiftUI

extension Color {
    static let deepNavyBlue = Color(red: 0.0, green: 0.0, blue: 0.5) // A custom deep navy blue
}
